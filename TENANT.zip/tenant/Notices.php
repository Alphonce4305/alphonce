
<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");

/*message to individual tenant*/
$house_code = null;$message = null;

if (isset($_POST['send'])) {

$message =addslashes ($_POST['message']);
$house_code = addslashes ($_POST['house_code']);
$from = $_SESSION['u_id'];
if(isset($house_code) && isset($message)){
if(!empty($house_code) && !empty($message)){
  
         // Get Recipient Id
          $check ="SELECT id FROM assigned_houses WHERE house_code='$house_code'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $getUSerID = mysqli_fetch_array($isExist,MYSQLI_ASSOC);
            $to = $getUSerID['id'];
           //INSERT MESSAGE
            $query = "INSERT INTO messages(sent_from,sent_to,message,senttime,seen) VALUES('$from','$to','$message',now(),'no')";  
            if(mysqli_query($conn, $query)){
              
                 $msg ="<p class='alert alert-success' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message sent !</p>";
                echo $msg;   
                //sleep(1) ; 
                header('Location: Notices.php');
                  exit();
               
            }else{

                $error ="<p class='alert alert-warning' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message not sent !!</p>";
                echo $error;
              }
                
            }else{
               $error ="<p class='alert alert-danger'style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>We Encountered a problem while sending the message !</p>";
                echo $error;
            }
          }
        }
      }/*end individual message*/
/*====================================================================================================
      THE CODE BELOW IS USED TO SEND MULTICAST MESSAGE WHICH WILL BE VISIBLE TO ALL BUT NON-REPLY
====================================================================================================*/

/*send broadcast message*/
$to_all = null; $broadcast = null;$is_form = null;
if (isset($_POST['toall'])) {

  $is_loggedin = $_SESSION['u_name'];
  $to_all = $_POST['all'];
  $broadcast =$_POST['broadcast'];
  $admin ="ADMIN";

  $is_form = $admin;

  $time = date("D M Y H:i:s A");


  if (isset($to_all) && isset($broadcast)) {
    if (!empty($to_all) && !empty($broadcast)) {
      $sql  = "INSERT INTO `notices` (`sender`, `recipient`, `mesage`, `sent_at`) VALUES('$is_form','$to_all','$broadcast','$time')";
      $sendBroadcast = mysqli_query($conn,$sql);

      if ($sendBroadcast == true) {
          $msg ="<p class='alert alert-success' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message sent !</p>";
          echo $msg; 
          header('Location:Notices.php?broadcast=sent');
      }else{
          echo "Failed";
      }
    }
  }
}



/*Endbroadcast message*/

$rooms=mysqli_query($conn, "SELECT house_no FROM houses WHERE flag ='Occupied'");

?>
<!-- message to individual tenant -->
<!--/span-->
        <div class="box col-md-4">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                  <h4 align="center">SEND MESSAGES TO TENANTS</h4>
                    <form action="" method="post">
                          <label for="house_code"><b>Message To:</b></label>
                          </br>
                          <?php
                          echo '<select name="house_code" class="form-control">';
                          echo '<option value="">Pick Tenant House No.</option>'; 
                          while($row = mysqli_fetch_array($rooms))
                          {

                           echo '<option value="'.$row['house_no'].'">'.$row['house_no'].'</option>';
                          }
                          echo '</select>';
                          ?>
                          <br>
                          <textarea class="form-control" name="message" placeholder="Hi,Admin send message to your tenants..." value="<?php echo $message; ?>" required=""></textarea>
                          <br>
                          <button type="submit" class="btn btn-primary" name="send">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
<!-- /end message to individual tenant -->




<!--/span-->
        <div class="box col-md-5">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <h4 align="center">MESSAGES</h4>
                    <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                    <!-- media left -->
                    <!-- GET MESSAGES -->
                    <?php 
                    $admin = "ADMIN";
                    $allmessages = mysqli_query($conn, "SELECT * FROM notices WHERE sender ='$admin'");

                      while ($row = mysqli_fetch_array($allmessages,MYSQLI_ASSOC)) {
                       //GRAB USERS NAMES
                        $reciever = $row['recipient'];
                        $sender = $row['sender'];

                        if ($sender === $admin) {
                          $message_holder ="You sent a message to";
                          $theReciever = "All Tenants";
                        }else {
                        $message_holder ="You recieved a message from";
                        $theReciever = "";
                        }
                        
                      echo '
                      <div class="media">
                            <div class="media-left">
                            <img src="avatar.png" class="media-object" style="width: 35px;">
                             </div><!-- end media-left -->
                               <div class="media-body">
                            <p>'.$message_holder.'&nbsp;<a href="">'.$theReciever.'</a><br>
                              <span  class="pull-right"><i style="color: green;font-size:10px;">'.$row['sent_at'].'</i><br><small class="pull-right" style="color:blue;"><i class="glyphicon glyphicon-ok"></i><i class="glyphicon glyphicon-ok"></i></small></span>
                              <small>'.$row['mesage'].'</small>
                        </div><!-- end media body -->
                      </div><!-- end media  -->
                      <hr>
                      ';
                    }
                    ?>    
                    </div>
            </div>
        </div>
        <!--/span-->



<!-- message to all -->
<!--/span-->
        <div class="box col-md-3" style="color: red;text-align: center;">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                    <form action="" method="post">
                          <label for="house_code"  ><b>Message To All</b></label>
                          </br>
                          <input type="hidden" name="all" value="all">
                          <br>
                          <textarea class="form-control" name="broadcast" placeholder="Hi,Admin send message to all tenants..."  required=""></textarea>
                          <br>
                          <button type="submit" class="btn btn-danger" name="toall">Broadcast</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
<!-- /end message to all -->
<?php  include_once 'includes/footer.php'; ?>
