<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/usernav.php'; 
include ("includes/database_connect.php");
?>
 <!--/span-->
        <div class="box col-md-6">
            <div class="box-inner">
                <div class="box-header well" data-original-title="" style="max-height: 450px; overflow-y: scroll;">
                	<a style="color: green;" href="send.php?user=<?php echo $_SESSION['u_id'];?>"><small class="pull-right" style="color: red;">chat<br><i style="font-size: 16px;" class="glyphicon glyphicon-comment"></i></small></a>
                    <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                    <!-- media left -->
                    <!-- GET MESSAGES -->
                    <?php 
                    $me = $_SESSION['u_id'];
                    $me_name = $_SESSION['u_name'];
                    
                    // MAP SESSION ID TO TENANT HOLDER
                     $getmsg=mysqli_query($conn, "SELECT id FROM assigned_houses WHERE tenant_name ='$me_name' ");
                     $getId = mysqli_fetch_array($getmsg,MYSQLI_ASSOC);
                     $recieverId = $getId['id'];

                    $messages=mysqli_query($conn, "SELECT * FROM messages WHERE sent_from ='$me' OR sent_to = '$recieverId' ORDER BY senttime DESC");
                    $msgCount = mysqli_num_rows($messages);
                    if ($msgCount < 1) {
                    	echo "<p align='center'>You Do not have messages yet </p>";
                    }
                      while ($row = mysqli_fetch_array($messages,MYSQLI_ASSOC)) {
                       
                        //HANDLE SEEN MESSAGES
                        //$row['seen'];
                        if ($row['seen'] =='no') {
                        	$_seen = "<span style='color:red;float:right;'><i class='glyphicon glyphicon-ok'></i><i class='glyphicon glyphicon-remove'></i></span>";
                        }elseif ($row['seen'] =='yes') {
                        	$_seen = "<span style='color:red;float:right;'><i class='glyphicon glyphicon-ok'></i><i class='glyphicon glyphicon-ok'></i></span>";
                        }

                        //GRAB USERS NAMES
                        $reciever = $row['sent_to'];
                        $sender = $row['sent_from'];

                       

                        //GET RECIPIENT
                        $getRecipient = mysqli_query($conn, "SELECT * FROM assigned_houses WHERE id ='$reciever'");
                        $foundReciever = mysqli_fetch_array($getRecipient,MYSQLI_ASSOC);
                        $the_Reciever = $foundReciever['tenant_name'];

              
                        //GET SENDER
                        $getRecipient = mysqli_query($conn, "SELECT fname,sname FROM tenant_details WHERE id ='$sender'");
                        $foundReciever = mysqli_fetch_array($getRecipient,MYSQLI_ASSOC);
                        $theReciever = $foundReciever['fname'];

                          //OUTPUT MESSAGES
                         if ($sender === $me) {
                          $message_holder ="<small style='color:green;'>Message to  <a href=''>".$the_Reciever."</a></small>";
                        }else{
                          $message_holder ="<small style='color:red;'>Message from <a href=''>".$theReciever."</a></small>";
                        }
                        //PREVENT SELF REPLY

                        if ($theReciever == $me_name) {
                            $show_reply_button ='';
                        }else{
                          $show_reply_button ='<span class="btn btn-default btn-xs"><a href="reply.php?user='.$theReciever.'" style="text-decoration:none;">Reply</a></span>';
                        }

                      echo '
                      <div class="media">
                            <div class="media-left">
                            <img src="avatar.png" class="media-object" style="width: 35px;">
                             </div><!-- end media-left -->
                               <div class="media-body">

                            <p>'.$message_holder.'<br>
                              <span  class="pull-right"><small style="color: green;font-size:10px;">'.$row['senttime'].'</small><br><small style="font-size:10px;">Delivered'.$_seen.'</small></span>
                              <p style="font-family:pristina;font-size:18px;">'.$row['message'].'</p>
                              <p >'.$show_reply_button.'</a></p>
                        </div><!-- end media body -->
                      </div><!-- end media  -->
                      <hr>
                      ';
                    }
                    ?>    
                    </div>
            </div>
        </div>
        <!--/span-->

         <!--/span-->
        <div class="box col-md-5">
            <div class="box-inner">
                <div class="box-header well" data-original-title="" style="max-height: 450px; overflow-y: scroll;">
                  <h4 align="center">MESSAGES FROM ADMIN</h4>
                    <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                    <!-- media left -->
                    <!-- GET MESSAGES -->
                    <?php 
                    $admin = "all";
                    $allmessages = mysqli_query($conn, "SELECT * FROM notices WHERE recipient ='$admin'");

                      while ($row = mysqli_fetch_array($allmessages,MYSQLI_ASSOC)) {
                       //GRAB USERS NAMES
                        $reciever = $row['recipient'];
                        $sender = $row['sender'];

                        if ($sender === $admin) {
                          $message_holder ="You sent a message to";
                          $theReciever = "All Tenants";
                        }else {
                        $message_holder =" Message From";
                        $theReciever = "<a href=''>THE ADMINISTRATOR</a>";
                        }
                        
                      echo '
                      <div class="media">
                            <div class="media-left">
                            <img src="avatar.png" class="media-object" style="width: 35px;">
                             </div><!-- end media-left -->
                               <div class="media-body">
                            <p>'.$message_holder.'&nbsp;<a href="">'.$theReciever.'</a><br>
                              <span  class="pull-right"><i style="color: green;font-size:10px;">'.$row['sent_at'].'</i><br><small class="pull-right" style="color:blue;"><i class="glyphicon glyphicon-ok"></i><i class="glyphicon glyphicon-ok"></i></small></span><br>
                              <p style="font-family:Lucida Calligraphy;">'.$row['mesage'].'</p>
                              <span style="font-style:italic;color:green;"><i class="glyphicon glyphicon-phone"></i> +254-725-245-020</span> &nbsp;<span style="font-style:italic;color:green;"><i class="glyphicon glyphicon-envelope">&nbsp;</i>info@admin.co.ke</span>
                        </div><!-- end media body -->
                      </div><!-- end media  -->
                      <hr>
                      ';
                    }
                    ?>    
                    </div>
            </div>
        </div>
        <!--/span-->

<?php include_once 'includes/footer.php'; ?>