<?php 
include_once 'includes/header.php';
include_once 'includes/database_connect.php';

if (isset($_SESSION['u_uid'])){
 header('Location: index.php');
}
if (isset($_POST['sub'])) {


	$uid = mysqli_real_escape_string($conn,$_POST['email']);
	$pwd = mysqli_real_escape_string($conn,$_POST['pass']);

	//Error Handling
	//Empty fields
		if (empty($uid) || empty($pwd) ) {
			//header('Location:index.php?login=Empty');
			$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>All Fields Are Required!</p>";
			
			echo '<br>
						<div class="row" style=" width:95%;margin-left: 2%;">
						  <div class="col-sm-4 well" id="loginbox">
						  '.$error.'
						  <h3 align="center">LOGIN TO YOUR ACCOUNT</h3>
						  <hr>
						<form method="post" action="">
						<input type="text" name="email" placeholder="Email / ID" class="form-control" id="inputdefault" autocomplete="off" ><br>
						<input type="password" name="pass" placeholder="Your Password" class="form-control" id="inputdefault"><br>
						<input type="submit" name="sub" value="Login" class="btn btn-primary" style="margin-left: 35%;">
						</form><br>
						<p><span>&nbsp;&nbsp;</span>Forgot Password ? <a href="Resetpassword.php" target="_self">Reset</a></p>
						</div>
						</div>';
			exit();
		}else{
			$sql="SELECT email,id_no,password FROM tenant_details WHERE email='$uid'OR id_no='$uid'";
			$checkuser =mysqli_query($conn,$sql);
			$user_exist=mysqli_num_rows($checkuser);
			if ($user_exist < 1) {
				//header('Location:index.php?login=NoUSer');
				$error ="<p class='alert alert-danger'style='font-size:12px;text-align:center;'>Sorrry  No User With that Account !</p>";
				echo '<br>
						<div class="row" style=" width:95%;margin-left: 2%;">
						  <div class="col-sm-4 well" id="loginbox">
						  '.$error.'
						  <h3 align="center">LOGIN TO YOUR ACCOUNT</h3>
						  <hr>
						<form method="post" action="">
						<input type="text" name="email" placeholder="Email / ID" class="form-control" id="inputdefault" autocomplete="off"><br>
						<input type="password" name="pass" placeholder="Your Password" class="form-control" id="inputdefault"><br>
						<input type="submit" name="sub" value="Login" class="btn btn-primary" style="margin-left: 35%;">
						</form><br>
						<p><span>&nbsp;&nbsp;</span>Forgot Password ? <a href="Resetpassword.php" target="_self">Reset</a></p>
						</div>
						</div>';
				exit();
			}else{
				if ($row=mysqli_fetch_array($checkuser,MYSQLI_ASSOC)){
					//De-hashing password
					$dbPass =  $row['password'];
					//$hashedPwdCheck= password_verify($pwd, $row['password']);
					if (hash('sha256', $pwd) !== $dbPass){
						$error ="<p class='alert alert-danger'style='font-size:12px;text-align:center;'>Invalid Login Credentials !</p>";
						
						echo '<br>
						<div class="row" style=" width:95%;margin-left: 2%;">
						  <div class="col-sm-4 well" id="loginbox">
						  '.$error.'
						 <h3 align="center">LOGIN TO YOUR ACCOUNT</h3>
						  <hr>
						<form method="post" action="">
						<input type="text" name="email" placeholder="Email / ID" class="form-control" id="inputdefault" autocomplete="off"><br>
						<input type="password" name="pass" placeholder="Your Password" class="form-control" id="inputdefault"><br>
						<input type="submit" name="sub" value="Login" class="btn btn-primary" style="margin-left: 35%;">
						</form><br>
						<p><span>&nbsp;&nbsp;</span>Forgot Password ? <a href="Resetpassword.php" target="_self">Reset</a></p>
						</div>
						</div>';
					//header('Location:index.php?login=Invalid');
						exit();	
					}elseif (hash('sha256', $pwd) == $dbPass) {
						//Log user in
						$getUser = "SELECT * FROM tenant_Details WHERE password ='$dbPass' LIMIT 1";
						$DBusers = mysqli_query($conn,$getUser);
						foreach ($DBusers as $user) {
						$_SESSION['u_id'] =  $user['id'];
						$_SESSION['u_name'] = $user['fname'];
						$_SESSION['u_email'] = $user['email'];
						$_SESSION['u_uid'] = $user['id_no'];
						$_SESSION['u_lname'] = $user['sname'];
						$_SESSION['u_cat'] = $user['cat'];

						}
						$loggedInUser = $_SESSION['u_id'];
						//UPDATE STATUS TO ONLINE
						$sql_online = "UPDATE tenant_details SET online = '1',onlinetime = now() WHERE id = '$loggedInUser' LIMIT 1";
						$set_online = mysqli_query($conn,$sql_online);
						if ($set_online == true) {
							// SET MESSAGES TO SEEN

							//GET USER ID FROM ASSIGNED HOUSES WHICH HOLDS THE MESSAGE
							$user_name = $_SESSION['u_name'];
							$sqlget	= "SELECT id FROM assigned_houses WHERE tenant_name = '$user_name'";
							$result = mysqli_query($conn,$sqlget);
							$chatId = mysqli_fetch_array($result,MYSQLI_ASSOC);
							$UserchatId =$chatId['id'];

						$sql_seen = "UPDATE messages SET seen = 'yes' WHERE sent_to = '$UserchatId' ";
						$set_seen = mysqli_query($conn,$sql_seen);
						}
						
						$msg ="<p class='alert alert-success' style='width:auto;font-size:14px;text-align:center;'>You Have Successfully Logged In</p>";
						echo $msg;
						header('Location:index.php?login=Success');
							
					}
				}
			}
		}

}else{?>

<br>
<div class="row" style=" width:95%;margin-left: 2%;">
  <div class="col-sm-4 well">
  <div class="panel-heading"><h3 align="center">LOGIN TO YOUR ACCOUNT</h3></div>
  <hr>
  <div class="panel-body">
<form method="post" action="">
<input type="text" name="email" placeholder="Email / ID" class="form-control" id="inputdefault" autocomplete="off"><br>
<input type="password" name="pass" placeholder="Your Password" class="form-control" id="inputdefault"><br>
<input type="submit" name="sub" value="Login" class="btn btn-primary" style="margin-left: 35%;">
</form><br>
<p><span>&nbsp;&nbsp;</span>Forgot Password ? <a href="Resetpassword.php" target="_self">Reset</a></p>
</div>
</div>
</div>

<?php
}

 ?>
