<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/database_connect.php';

$userId = null;
$password_new = null;
$password_new_again = null;
if (isset($_POST['submit'])) {
	$userId =$_POST['password_current'];
	$password_new = $_POST['password_new'];
	$password_new_again = $_POST['password_new_again'];


	if (isset($userId) && isset($password_new) && isset($password_new_again)) {
		if (empty($userId) || empty($password_new) || empty($password_new_again)) {

			// CATCH EMPTY SUBMISSIONS
			$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>All Fields Are Required!</p>";
			echo $error;
		}else{
			//MATCH POSTED PASSWORDS
			if ($password_new !==$password_new_again ) {
				$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>Passwords Do Not Match !</p>";
			echo $error;
			}

			//CHECK USER EXISTENCE
			$sql = "SELECT fname,email,id_no,online FROM tenant_details WHERE fname = '$userId' OR email = '$userId' OR id_no = '$userId' AND online ='0' ";
			$QueryRun = mysqli_query($conn,$sql);

			//CHECK USERS FOUND
			$is_found = mysqli_num_rows($QueryRun);
			if ($is_found > 1) {
				//TRY ANOTHER FIELD
				$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>Try with others!</p>";
					echo $error;
			}elseif($is_found == 1){
				// USER FOUND UPDATE 

				/*GRAB INDIVIDUAL USER ID*/
				$SQL ="SELECT id FROM tenant_details WHERE fname = '$userId' OR email = '$userId' OR id_no = '$userId'";
				$Query = mysqli_query($conn,$SQL);
				$getUserId = mysqli_fetch_array($Query,MYSQLI_ASSOC);
				$user_id = $getUserId['id'];

				//HASH INCOMING PASSWORD
				$new_password = hash('sha256', $password_new);
				//UPDATE PASSWORD FIELD WITH NEW PASSWORD
				$sql_update = "UPDATE tenant_details SET password = '$new_password' WHERE id = '$user_id' LIMIT 1";
				$RunUpdateQuery = mysqli_query($conn,$sql_update);
				if ($RunUpdateQuery == true) {
					$msg ="<p class='alert alert-success' style='width:auto;font-size:14px;text-align:center;'>Password Changed Successfully<br>
						<span class='btn btn-info' ><a href='index.php' style='color:red;text-decoration:none;'><i class = 'glyphicon glyphicon-hand-right'></i> LOGIN HERE</a></span></p>";
						echo $msg;

				}else{
					echo "Unable to Update Password !";
				}

			}elseif ($is_found == 0) {
				$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>Invalid </p>";
					echo $error;
			}
		}
			}else{
				$error ="<p class='alert alert-warning'style='font-size:12px;text-align:center;'>Technical Error Occured!</p>";
					echo $error;
			}
		}else{
			$error ="<p class='alert alert-default'style='font-size:12px;text-align:center;'>Ooops! You Forgot Your Password ! </p>";
			echo $error;
}

?>


<div class="panel panel-primary" style="width: 95%; margin-left: 2%; margin-top: 2%; text-align: center;">
	
<div class="panel-heading"><h6>Reset Password</h6></div>
<div class="panel-body" >
<form action="?" method="POST">
	<div class="form-group">
 		<label for="password_current" class="sr-only">Curent Password</label>
 		<input type="text" name="password_current" id=" password_current" class="form-control" placeholder="Enter IDNO./Email/Firstname" autocomplete="off">
 	</div>
 	<br>
	<div class="form-group">
 		<label for="password_new" class="sr-only">New Password</label>
 		<input type="password" name="password_new" id="password_new" class="form-control" placeholder="Enter New Password">
 	</div>
 	<br>
 	<div class="form-group" >
 		<label for="password_new_again" class="sr-only">Confirm New Password</label>
 		<input type="password" name="password_new_again" id="password_new_again" class="form-control" placeholder="Re-Enter New Password">	
 	</div>
 	<input type="submit" name="submit" value="Reset Password" class="btn btn-warning">
 </form>
 </div>
 </div>
 <?php include_once 'includes/footer.php'; ?>