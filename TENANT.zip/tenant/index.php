
<?php 
session_start();
include_once 'includes/header.php';
if (isset($_SESSION['u_id']) || isset($_SESSION['u_uid'])) {
//Check User Category
  $isLoggedIn =$_SESSION['u_id'];
  include_once 'includes/database_connect.php';
  $sql ="SELECT * FROM tenant_Details WHERE id ='$isLoggedIn'";
  $loggeduser = mysqli_query($conn,$sql);
  foreach ($loggeduser as $loggedIn) {
    $loggedCat =$loggedIn['cat'];
  }
  if ($loggedCat == 'user') {

if (isset($_SESSION['u_id'])) {
  #check if is online
  $isLoggedIn =$_SESSION['u_id'];
  $sql ="SELECT * FROM tenant_Details WHERE id ='$isLoggedIn'";
  $isloggeduser = mysqli_query($conn,$sql);
  foreach ($loggeduser as $isloggedIn) {
    $isOnline =$isloggedIn['online'];
  }

  if ( $isOnline == '0') {
    //logout user out
    header('Location:includes/logout.php');
  }
}


    // SHOW USER NAVBAR
    include_once 'includes/usernav.php';?>
     <div class="panel panel-primary" style="text-align: center;">
       <div class="panel-heading"><h2><?php echo $_SESSION['u_name'] .$_SESSION['u_lname']; ?></h2></div>
       <div>
         <h3>YOU ARE LOGGED IN AS TENANT</h3>
         <h5>......Please Feel Welcomed.......</h5>
         <h6><u>OUR SERVICES</u></h6>

         <ul class="nav nav-pills" style="text-align: center;margin-left: 35%;font-size: 14px; font-weight: bold;">
           <li><i class="glyphicon glyphicon-hand-down"></i><a href="Pay.php"> PAY MY ROOM</a></li>
           <li><i class="glyphicon glyphicon-hand-down"></i><a href="Reports.php">MY REPORTS</a></li>
           <li><i class="glyphicon glyphicon-hand-down"></i><a href="Notification.php">MESSAGES</a></li>
         </ul>
       </div>
     </div>
  
  <?php
  }elseif ($loggedCat == 'admin') {
    // SHOW ADMIN NAVBAR
  include_once 'includes/nav.php'; 
  
  echo $_SESSION['u_email'],"<br>","You are Logged In As Administrator";
  }
}else{
  require_once 'login.php';

}
?>

<?php include_once 'includes/footer.php'; ?>
