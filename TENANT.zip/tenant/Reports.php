<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/usernav.php'; 
include ("includes/database_connect.php");
?>
 <!--/span-->
        <div class="box col-md-10">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <p align="center"><?php echo $_SESSION['u_name'].$_SESSION['u_lname'] ;?></p>
                  
                  <h6 align="center">MY REPORTS</h6>
                    <table class="table table-stripped" >
                    <thead class="alert alert-primary">
                      <th class="center" id="small_screen">#</th>
                      <th class="center" id="small_screen">HSE </th>
                      <th class="center">AMOUNT PAID</th>
                      <th class="center" id="small_screen">ITEM PAID</th>
                      <th class="center">DATE OF PAY</th>
                      <th class="center">DATE CHECKED</th>
                      <th class="center">STATUS</th>
                    </thead>
                    <?php 
                    $loggedInUser =$_SESSION['u_email'];
                    $SQL = "SELECT * FROM tenantrent WHERE tenant_email='$loggedInUser'";
                    $getReport = mysqli_query($conn,$SQL);
                    $x=1;
                      while ($row = mysqli_fetch_array($getReport,MYSQLI_ASSOC)) {
                        //DISPLAY ALL ROOMS AND BUILDING
                      //DISPLAY ALL ROOMS AND BUILDING
                          /*Deal with status dispaly*/
                          $status = $row['status'];

                          if ($status == 'pending') {
                            # display not paid 
                            $display = '<span style="color:red;"> <i class="glyphicon glyphicon-warning-sign"></i>Pending...</span>';
                          }elseif($status =='approved') {
                            # display paid
                            $display = '<p style="color:green;"><span> <i class="glyphicon glyphicon-ok"></i>Approved</span></p>';
                          }
                      echo '
                      <tbody>
                      <td class="center" id="small_screen">'.$x++.'</td>
                      <td class="center" id="small_screen">'.strtoupper($row['house_code']).'</td>
                      <td class="center"> Kshs.'.strtoupper($row['amount']).'</td>
                      <td class="center" id="small_screen">'.ucfirst($row['paidfor']."-".$row['reason']).'</td>
                      <td class="center">'.strtoupper($row['paidon']).'</td>
                      <td class="center">'.$row['action'].'</td>
                      <td class="center">'.$display.'</td>
                      </tbody>';
                      }
                     ?>
      
               </table>
                </div>
            </div>
        </div>
        <!--/span-->

<?php include_once 'includes/footer.php'; ?>