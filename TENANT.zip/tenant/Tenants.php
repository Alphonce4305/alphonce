<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");
?>
 <!--/span-->
        <div class="box col-md-10" style="margin-left: 5%;">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">

                  <!-- <a href="Reports/index.php"><span class="pull-right" style="color: red;"><i class="glyphicon glyphicon-print glyphicon-lg"></i></span></a> -->
                  <h6 align="center">TENANTS LIST</h6>
                    <table class="table table-stripped" >
                    <thead class="alert alert-primary">
                      <th class="center">#</th>
                      <th class="center">TENANT NAME</th>
                      <th class="center">TENANT CONTACT</th>
                      <th class="center">TENANT ID</th>
                      <th class="center">HOUSE OCCUPIED</th>
                      <th class="center">APPARTMENT</th>
                      <th class="center">DATE IN</th>
                    </thead>
                    <?php 
                    $SQL = "SELECT a.fname,a.sname,a.email,a.id_no, b.hname,b.htype,c.tenant_name,c.house_code,c.datein, d.house_no FROM tenant_details a ,house_details b ,assigned_houses c, houses d WHERE c.house_code = d.house_no AND a.fname = c.tenant_name";
                    $getReport = mysqli_query($conn,$SQL);
                    $x=1;
                      while ($row = mysqli_fetch_array($getReport,MYSQLI_ASSOC)) {
                        //DISPLAY ALL ROOMS AND BUILDING
                  
                      echo '
                      <tbody>
                      <td class="center">'.$x++.'</td>
                      <td class="center">'.ucfirst($row['fname'].$row['sname']).'</td>
                      <td class="center">'.ucfirst($row['email']).'</td>
                      <td class="center">'.ucfirst($row['id_no']).'</td>
                      <td class="center">'.strtoupper($row['house_code']).'</td>
                      <td class="center">'.strtoupper($row['hname']).'</td>
                      <td class="center">'.strtoupper($row['datein']).'</td>
                      </tbody>';
                      }
                     ?>
      
               </table>
                </div>
            </div>
        </div>
        <!--/span-->

<?php include_once 'includes/footer.php'; ?>