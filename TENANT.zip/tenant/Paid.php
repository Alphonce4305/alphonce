<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");
?>
 <!--/span-->
        <div class="box col-md-8" style="margin-left: 15%;">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <h6 align="center">CURRENT PAYMENTS</h6>
                    <table class="table table-stripped" >
                    <thead class="alert alert-primary">
                      <th class="center">#</th>
                      <th class="center">HSE </th>
                      <th class="center">AMOUNT PAID</th>
                      <th class="center">ITEM PAID</th>
                      <th class="center">TENANT</th>
                      <th class="center">DATE OF PAY</th>
                      <th class="center">ACTION</th>
                    </thead>
                    <?php 
                    $loggedInUser =$_SESSION['u_email'];
                    $SQL = "SELECT * FROM tenantrent";
                    $getReport = mysqli_query($conn,$SQL);
                    $x=1;
                      while ($row = mysqli_fetch_array($getReport,MYSQLI_ASSOC)) {
                        //DISPLAY ALL ROOMS AND BUILDING
                          /*Deal with status dispaly*/
                          $status = $row['status'];
                          $user_id =  $row['id'];
                          if ($status == 'pending') {
                            # display not paid edit tools
                            $display ='<a href="includes/approve.php?user='.$user_id.'"><span class="btn btn-success btn-xs"><i class="glyphicon glyphicon-ok" ></i></span></a>&nbsp;<a href="includes/reject.php?user='.$user_id.'"><span class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-remove" ></i></span></a>';
                          }elseif($status =='approved') {
                            # display paid
                            $display = '<p style="color:green;"><span><i class="glyphicon glyphicon-ok"></i>APPROVED</span></p>';
                          }elseif ($status == 'rejected') {
                            # display rejected
                            $display = '<p style="color:red;"><span><i class="glyphicon glyphicon-warning-sign"></i> REJECTED</span></p>';
                          }
                      echo '
                      <tbody>
                      <td class="center">'.$x++.'</td>
                      <td class="center">'.strtoupper($row['house_code']).'</td>
                      <td class="center"> Kshs.'.strtoupper($row['amount']).'</td>
                      <td class="center">'.ucfirst($row['paidfor']."-".$row['reason']).'</td>
                       <td class="center">'.ucfirst($row['tenant_email']).'</td>
                      <td class="center">'.strtoupper($row['paidon']).'</td>
                      <td class="center">'.$display.'</td>
                      </tbody>';
                      }
                     ?>
      
               </table>
                </div>
            </div>
        </div>
        <!--/span-->

<?php include_once 'includes/footer.php'; ?>