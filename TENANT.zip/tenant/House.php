
<?php 
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");

if (!isset($_POST['addhouse'])) {
  $hname = null;
$hlocation = null;
$htype = null;
$rprice = null;
$rooms = null;
}elseif(isset($_POST['addhouse'])){

$hname = addslashes($_POST['hname']);
$hlocation =addslashes ($_POST['hlocation']);
$htype =addslashes ($_POST['htype']);
$rooms =addslashes ($_POST['rooms']);

if(isset($hname) && isset($hlocation) && isset($htype)  && isset($rooms)){
  if(!empty($hname) ||  !empty($hlocation) || !empty($htype) || !empty($rooms)){

 // check if house exists
          $check ="SELECT hname FROM house_details WHERE hname='$hname'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>House Already Exists !</p>";
                  echo $error;
                  
          }else{

  $query = "INSERT INTO house_details(hname,hlocation,htype,room) values('$hname','$hlocation','$htype','$rooms')";

  if(mysqli_query($conn, $query)){
    $msg ="<p class='alert alert-success' style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>You Have Successfully Added New Room</p>";
    echo $msg;
    
}
  else
  {
   $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>We Encountered Problem Adding New House!</p>";
  echo $error;
  }
}
}
}
}
$filter=mysqli_query($conn,"SELECT type FROM house_types");
$menu=" ";

?>
<?php 

//DISPLAY ALL ROOMS AND BUILDINGS
include ("includes/database_connect.php");
$SQL_ROOMS ="SELECT a.building,a.house_no,a.price,a.flag, b.id,b.hname ,c.tenant_name,c.house_code, c.datein FROM houses a,house_details b ,assigned_houses c WHERE a.building = b.id AND a.house_no = c.house_code";
$ROOMS = mysqli_query($conn,$SQL_ROOMS);


//DISPLAY ALL ROOMS AND BUILDINGS
include ("includes/database_connect.php");
$SQL_BUILDING ="SELECT * FROM `house_details`";
$BUILDING = mysqli_query($conn,$SQL_BUILDING);

 ?>



    <div class="row">
        <div class="box col-md-4">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <form action="" method="POST">
                        <h6 align="center">REGISTER NEW BUILDING</h6>
                        <hr>
                        <label for="hname"><b>APPARTMENT</b></label>
                        <input type="text" placeholder="E.g Ruma Appartments" name="hname" class="form-control" required="" value="<?php echo $hname;?>">

                        <label for="hlocation"><b>LOCATION</b></label>
                        <input type="text" placeholder="E.g Westlands" name="hlocation" class="form-control"  required="" value="<?php echo $hlocation;?>">

                          <label for="htype"><b>TYPE OF HOUSE</b></label>
                        </br>
                        <?php
                        echo '<select name="htype" class="form-control" >';
                        while($row = mysqli_fetch_array($filter))
                        {
                         echo '<option value="'.$row['type'].'">'.$row['type'].'</option>';
                        } 
                        echo '</select>';
                        ?>
                           <label for="rooms"><b>ROOMS.</b></label>
                            <input type="number" placeholder="011" name="rooms" class="form-control" required="" value="<?php echo $rooms;?>" min="0">
                        <hr>
                            <button type="submit" class="btn btn-primary" name="addhouse">Save</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
        <div class="box col-md-4">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <h6 align="center">BUILDINGS</h6>
                    <table class="table table-stripped" >
                    <thead class="alert alert-primary">
                      <th class="center">#</th>
                      <th class="center">NAME</th>
                      <th class="center">LOCATION</th>
                      <th class="center">TYPE</th>
                      <th class="center">ROOMS</th>
                    </thead>
                    <?php 
                    $x=1;
                      while ($row = mysqli_fetch_array($BUILDING,MYSQLI_ASSOC)) {
                        //DISPLAY ALL ROOMS AND BUILDING
                  
                      echo '
                      <tbody>
                      <td class="center">'.$x++.'</td>
                      <td class="center">'.strtoupper($row['hname']).'</td>
                      <td class="center">'.strtoupper($row['hlocation']).'</td>
                      <td class="center">'.strtoupper($row['htype']).'</td>
                      <td class="center">'.$row['room'].'</td>
                      </tbody>';
                      }
                     ?>
      
               </table>
                </div>
            </div>
        </div>
        <!--/span-->
        <div class="box col-md-4">
            <div class="box-inner" style="font-size: 12px;">
                <div class="box-header well" data-original-title="">
                  <a href="Room.php" target="_self" class="btn btn-info">+</a>
                   <h6 align="center">HOUSES</h6>
                  <table class="table table-stripped">
                  <thead class="alert alert-warning">
                    <th class="center">#</th>
                    <th class="center">HSE NO:</th>
                    <th class="center">BUILDING</th>
                    <th class="center">STATUS</th>
                    <th class="center">OCCUPANT</th>
                    <th class="center">FROM</th>
                  </thead>
                  
                  <tbody>
                    <?php 
                    $x=1;
                      while ($row = mysqli_fetch_array($ROOMS,MYSQLI_ASSOC)) {
  

                      echo '
                      <tbody>
                      <td class="center">'.$x++.'</td>
                      <td class="center">'.strtoupper($row['house_no']).'</td>
                      <td class="center">'.strtoupper($row['hname']).'</td>
                      <td class="center">'.strtoupper($row['flag']).'</td>
                      <td class="center">'.strtoupper($row['tenant_name']).'</td>
                      <td class="center">'.strtoupper($row['datein']).'</td>
                      </tbody>';
                      }
                     ?>
                  </tbody>
                </table>
      </div>
   </div>
 </div>
      
        <!--/span-->
    </div><!--/row-->


<?php include_once 'includes/footer.php'; ?>
