
<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/usernav.php'; 
include ("includes/database_connect.php");


if (isset($_GET['user'])) {
  $reply_to = $_GET['user'];
}
//MAKE USER DONT SEND MESSAGE TO HIMSELF

          //GRAB RECIPIENT HOUSE CODE
          
          $sqlGet = "SELECT house_code FROM `assigned_houses` WHERE tenant_name = '$reply_to'";
          $runQuery = mysqli_query($conn,$sqlGet);
          $is_exist = mysqli_fetch_array($runQuery,MYSQLI_ASSOC);
          $currentCode = $is_exist['house_code'];
          //GRAB OTHER USERS
          

$message = null;

if (isset($_POST['send'])) {

$message =addslashes ($_POST['message']);
$from = $_SESSION['u_id'];
if(isset($message)){
if(!empty($message)){
           
          // Get Recipient Id
          $check ="SELECT id FROM assigned_houses WHERE house_code='$currentCode'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $getUSerID = mysqli_fetch_array($isExist,MYSQLI_ASSOC);
            $to = $getUSerID['id'];
            $sent_time = date("D M Y H:i A");
           //INSERT MESSAGE
            $query = "INSERT INTO messages(sent_from,sent_to,message,senttime,seen) VALUES('$from','$to','$message','$sent_time','no')";  
            if(mysqli_query($conn, $query)){
              
                 $msg ="<p class='alert alert-success' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message sent !</p>";
                echo $msg;   
                //sleep(2) ; 
              header('Location: Notification.php?message=sent');
                
               
            }else{

                $error ="<p class='alert alert-warning' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message not sent !!</p>";
                echo $error;
              }
                
            }else{
               $error ="<p class='alert alert-danger'style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>We Encountered a problem while sending the message !</p>";
                echo $error;
            }
          }
        }
      }
        
?>

<!--/span-->
        <div class="box col-md-6">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                  <h4 align="center">Chatroom</h4>
                  <?php 

                  if (isset($_GET['user'])) {

            $reply_to = $_GET['user'];
                    //GRAB SENDERS ID
          
          $sqlGet = "SELECT id FROM `tenant_details` WHERE fname = '$reply_to'";
          $runQuery = mysqli_query($conn,$sqlGet);
          $is_exist = mysqli_fetch_array($runQuery,MYSQLI_ASSOC);
          $sending_id = $is_exist['id'];

          //GRAB LOGGED USER CHAT ID
          $mine = $_SESSION['u_name'];

          $sqlGet = "SELECT id FROM `assigned_houses` WHERE tenant_name = '$mine'";
          $runQuery = mysqli_query($conn,$sqlGet);
          $is_exist = mysqli_fetch_array($runQuery,MYSQLI_ASSOC);
          $me = $is_exist['id'];
          
          //HIDE MESSAGE FROM SELF SENDER
          $self_id = $_SESSION['u_id'];
          if ($self_id) {
            $getsentmsg = null;
            $reply_to =null;
          }
          //GRAB MESSAGE SENT TO LOGGED IN USER ONLY
          $sent_messages = mysqli_query($conn, "SELECT * FROM messages WHERE sent_from ='$sending_id' AND sent_to = '$me' ORDER BY senttime DESC");
            foreach ($sent_messages as $msg_sent) {
              $getsentmsg =  $msg_sent['message'];
            }
                  }

                  echo "<p style='font-size:18px;font-family:pristina;'>".$reply_to."<br>".ucfirst($getsentmsg)."</p>";
                  


                  ?>
                    <form action="" method="post">
                          <textarea class="form-control" name="message" placeholder="Reply..." required="" ></textarea>
                          <br>
                          <button type="submit" class="btn btn-primary" name="send">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
