
<?php 
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");

if (!isset($_POST['addnew'])) {
$building = null;
$house_no = null;
$price = null;
}elseif(isset($_POST['addnew'])){

$building = addslashes($_POST['building']);
$house_no =addslashes ($_POST['house_no']);
$price =addslashes ($_POST['price']);

if(isset($building) && isset($house_no) && isset($price)){
  if(!empty($building) ||  !empty($house_no) || !empty($price)){

 // check if house exists
          $check ="SELECT house_no FROM houses WHERE house_no='$house_no'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $error ="<p class='alert alert-danger'style='width:32%; margin-left:36%;font-size:20px;text-align:center;'>House Already Exists !</p>";
                  echo $error;
                  
          }else{

          //GET BUILDING ID

          $SQL_BUILDING ="SELECT id FROM house_details WHERE hname='$building' LIMIT 1";
          $BUILDING_ID = mysqli_query($conn,$SQL_BUILDING);
          $row = mysqli_fetch_array($BUILDING_ID,MYSQLI_ASSOC);
          $buildingId = $row['id'];
      

           //MATCH HOUSE CODE WITH BUILDING INITALS
            //EXTRACT TWO FIRST LETTERS
            $first_two = strtoupper(substr($building,0,2));
            
            $house_code =$first_two."/0".$house_no;

  $query = "INSERT INTO houses (building,house_no,price) values('$buildingId','$house_code','$price')";

  if(mysqli_query($conn, $query)){
    $msg ="<p class='alert alert-success' style='width:32%; margin-left:36%;font-size:20px;text-align:center;'>You Have Successfully Added New Room</p>";
    echo $msg;
    
}
  else
  {
   $error ="<p class='alert alert-danger'style='width:32%; margin-left:36%;font-size:20px;text-align:center;'>We Encountered Problem Adding New House!</p>";
  echo $error;
  }
}
}
}
}
$filter=mysqli_query($conn,"SELECT type FROM house_types");

//DISPLAY ALL ROOMS AND BUILDINGS
$SQL_BUILDING ="SELECT * FROM `house_details`";
$BUILDING = mysqli_query($conn,$SQL_BUILDING);

 ?>

    <div class="row">
        <div class="box col-md-4" style="margin-left: 35%;">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <form action="" method="POST">
                        <h6 align="center">REGISTER NEW HOUSE/ROOM</h6>
                        <hr>
                        <label for="building"><b>APPARTMENT</b></label>
                        <?php
                        echo '<select name="building" class="form-control" >';
                        while($row = mysqli_fetch_array($BUILDING))
                        {
                         echo '<option value="'.$row['hname'].'">'.$row['hname'].'</option>';
                        } 
                        echo '</select>';
                        ?>

                        <label for="hlocation"><b>HOUSE NO:</b></label>
                        <input type="text" placeholder="E.g 024" name="house_no" class="form-control"  required="" value="<?php echo $house_no;?>">
                           <label for="rooms"><b>HOUSE PRICE</b></label>
                            <input type="number" placeholder="50,000" name="price" class="form-control" required="" value="<?php echo $rooms;?>" min="0">
                        <hr>
                            <button type="submit" class="btn btn-primary" name="addnew">Save</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
    </div><!--/row-->


<?php include_once 'includes/footer.php'; ?>
