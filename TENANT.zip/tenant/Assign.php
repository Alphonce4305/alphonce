
<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/nav.php'; 
include ("includes/database_connect.php");

if (!isset($_POST['assign'])) {
  $tenant = null;
$appartment =null;
$house_code = null;
}else{

$tenant = addslashes ($_POST['tenant']);
$appartment =addslashes ($_POST['appartment']);
$house_code = addslashes ($_POST['house_code']);

if(isset($tenant) && isset($appartment) && isset($house_code)){
        if(!empty($tenant) && !empty($appartment) && !empty($house_code)){

          // check if house has been assigned
          $check ="SELECT house_code FROM assigned_houses WHERE house_code='$house_code'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $error ="<p class='alert alert-warning'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>House Has Been Assigned !</p>";
                  echo $error;
                  
          }else{

        $query = "INSERT INTO assigned_houses(tenant_name,house_code,datein) VALUES('$tenant','$house_code',now())";

        if(mysqli_query($conn, $query)){

          //UPDATE ROOMS

              $updateroom=mysqli_query($conn, "UPDATE houses SET flag ='Occupied' WHERE house_no='$house_code' LIMIT 1");
              if ($updateroom) {
                 $msg ="<p class='alert alert-success' style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>Room Assigned Successfully</p>";
                echo $msg;
              }
                
        }
        else
        {
               $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>We Encountered Problem Assigning This Room!</p>";
                echo $error;

        }
}
}
}
}


$tenant=mysqli_query($conn,"SELECT fname FROM tenant_details WHERE cat='user'");
$houses=mysqli_query($conn, "SELECT hname FROM house_details");
$rooms=mysqli_query($conn, "SELECT house_no FROM houses WHERE flag='Empty'");


?>
<div class="container" style="width: 45%; margin-left: 25%;">
<form action="" method="post">
    <h2 align="center">ALLOCATE HOUSE</h2>
    <hr>

<label for="htype"><b>TENANT NAME</b></label>

</br>

<?php
echo '<select name="tenant" class="form-control">';
while($row = mysqli_fetch_array($tenant))
{
 echo '<option value="'.$row['fname'].'">'.$row['fname'].'</option>';
}
echo '</select>';
?>
<hr>

<label for="htype"><b>APPARTMENT</b></label>
</br>
<?php
echo '<select name="appartment" class="form-control">';
while($row = mysqli_fetch_array($houses))
{
 echo '<option value="'.$row['hname'].'">'.$row['hname'].'</option>';
}
echo '</select>';
?>
<hr>

<label for="house_code"><b>HOUSE NO</b></label>
</br>
<?php
echo '<select name="house_code" class="form-control">';
while($row = mysqli_fetch_array($rooms))
{
 echo '<option value="'.$row['house_no'].'">'.$row['house_no'].'</option>';
}
echo '</select>';
?>

<hr>
    <button type="submit" class="btn btn-primary" name="assign">Assign Room</button>
</form>
</div>
</div>
<?php  include_once 'includes/footer.php'; ?>
