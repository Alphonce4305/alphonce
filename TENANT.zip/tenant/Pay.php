
<?php 
session_start();
include_once 'includes/header.php';
include_once 'includes/usernav.php'; 
include ("includes/database_connect.php");



if (isset($_POST['pay'])) {
  if (isset($_SESSION['u_id']) || isset($_SESSION['u_uid'])) {
   $email = $_SESSION['u_email'];
   $loggedUser = $_SESSION['u_name']; 
}
// GET HOUSE OF THE TENANT
$sql ="SELECT house_code FROM assigned_houses WHERE tenant_name='$loggedUser' ";
$setHouse = mysqli_query($conn,$sql);
$getCode = mysqli_fetch_array($setHouse,MYSQLI_ASSOC);
$house_code =$getCode['house_code'];
$amount = $_POST['amount'];
$reason = $_POST['reason'];
$period = $_POST['period'];
if(isset($amount) && isset($email) && isset($reason) && isset($period)){

$query = "INSERT INTO tenantrent(house_code,tenant_email,amount,paidfor,paidon,reason) 
          VALUES('$house_code','$email','$amount','$period',now(),'$reason')";

if(mysqli_query($conn, $query) == true){
  $msg ="<p class='alert alert-success' style='width:30%; margin-left:36%;font-size:16px;text-align:center;'>Payment Made Successfully</p>";
    echo $msg;
    unset($_POST['pay']);
        }else{
                $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:16px;text-align:center;'>We Encountered Problem Making Payment!</p>";
                  echo $error;

        }
    }
  
}



?>

<div class="panel panel-warning">
  <div class="panel-heading"><h3 align="center">RENT PAYMENT</h3></div>
  <h4 align="center"><?php echo $_SESSION['u_name'].$_SESSION['u_lname'];; ?></h4>
  <p align="center">Make Payment Below:</p>
  <div class="panel-body">
<form action="" method="post">
    <label for="period">Payment Month</label>
   <select name="period" class="form-control">
     <optgroup>
       <option value="">Select Month To Pay</option>
       <option value="January">January</option>
       <option value="February">February</option>
       <option value="Match">Match</option>
       <option value="April">April</option>
       <option value="May">May</option>
       <option value="June">June</option>
       <option value="July">July</option>
       <option value="August">August</option>
       <option value="September">September</option>
       <option value="October">October</option>
       <option value="November">November</option>
       <option value="December">December</option>
     </optgroup>
   </select>
    <label for="reason">Payment Reason</label>
    <select name="reason" class="form-control">
      <optgroup>
        <option value="">Select Reason Of Payment</option>
        <option value="normal">Normal Rent</option>
        <option value="advance">Advance Payment</option>
        <option value="penalty">Penalty Payment</option>
      </optgroup>
    </select>
    <label for="amount"><b>Amount Payed:</b></label>
    <input type="number" placeholder=" e.g Kshs 1,000" name="amount" required="" class="form-control" min="1000" value="<?php echo $amount;?>"><br>
    <input type="submit" class="btn btn-warning" name="pay" value="Pay">
  </div>
</form>
</div>
</div>
<?php include_once 'includes/footer.php'; ?>

