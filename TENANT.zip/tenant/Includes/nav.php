<style>
	.topnav > a{
		text-decoration: none;
	}
	.topnav > a >span{
		color: red;
	}
</style>

<div class="topnav">
  <a class="active" href="index.php"><span> <i class="glyphicon glyphicon-home"></i> </span>HOME</a>
  <a href="House.php"><span><i class="glyphicon glyphicon-home"></i><i class="glyphicon glyphicon-home"></i></span>BUILDINGS</a>
  <a href="Tenant.php"><span> <i class="glyphicon glyphicon-user"></i><i class="glyphicon glyphicon-user"></i> </span>ADD TENANT</a>
  <a href="Assign.php"><span> <i class="glyphicon glyphicon-lock"></i> </span>ASSIGN HOUSE</a>
  <a href="Paid.php"><span> <i class="glyphicon glyphicon-briefcase"></i> </span>PAYMENTS</a>
  <a href="Tenants.php"><span> <i class="glyphicon glyphicon-list-alt"></i> </span>TENANT REPORTS</a>
  <a href="Notices.php"><span> <i class="glyphicon glyphicon-bell"></i> </span>NOTICES</a>
  <a href="includes/logout.php"><span> <i class="glyphicon glyphicon-log-out"></i> </span>LOGOUT</a>
</div>
