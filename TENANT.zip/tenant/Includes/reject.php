<?php

include_once 'database_connect.php';

// GRAB INDIVIDUAL USER ID SENT

if (isset($_GET['user'])) {
	$user_id = $_GET['user'];
}
//UPDATE PAYMENT STATUS
$date = date("D M Y H:i:s A");

$sql = "UPDATE `tenantrent` SET `status` = 'rejected',`action` = '$date' WHERE `tenantrent`.`id` = '$user_id'";
$update = mysqli_query($conn,$sql);
//Catch erro
if ($update == true) {
	header('Location:../Paid.php');
}else{
	header('Location:../Paid.php');
	
}




?>