<?php 
session_start();
include_once 'database_connect.php';

if (isset($_SESSION['u_id'])||isset($_SESSION['u_email'])) {
$loggedInUser = $_SESSION['u_id'];
//UPDATE STATUS TO OFFLINE
$sql_offline = "UPDATE tenant_details SET online = '0', onlinetime = now() WHERE id = '$loggedInUser'AND online = '1' LIMIT 1";
$set_offline = mysqli_query($conn,$sql_offline);

if ($set_offline == true) {
	session_destroy();
	session_unset();
	header('Location:../index.php');
}
}







  ?>