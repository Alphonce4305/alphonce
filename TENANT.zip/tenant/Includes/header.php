
<!DOCTYPE html>
<html>
<head>
	<title>PPMIS</title>
<!-- <link rel="stylesheet" type="text/css" href="style/stylesheetregister.css"> -->
<link rel="stylesheet" type="text/css" href="style/stylesheet.css">
<!-- <link rel="stylesheet" type="text/css" href="style/loginstylesheet.css"> -->
<link rel="stylesheet" type="text/css" href="style/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="style/css/bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="style/css/bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="style/css/bootstrap.min.css">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="style/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="style/bootsrap/css/bootstrap.css">


</head>
<body style="background-color: #fff;">
	<style>
		a{text-decoration: none;}

		@media only screen and (max-width: 989px) {
			#small_screen{
				display: none;
			}
		}

	</style>