

<style>
	.topnav > a{
		text-decoration: none;
	}
	.topnav > a >span{
		color: red;
	}
	.topnav > a:active{
		background-color: blue;
	}
</style>

<div class="topnav">
  <a class="" href="index.php"><span> <i class="glyphicon glyphicon-home"></i> </span>HOME</a>
  <a href="Pay.php"><span> <i class="glyphicon glyphicon-briefcase"></i> </span>ROOM PAYMENT</a>
  <a href="Reports.php"><span> <i class="glyphicon glyphicon-list-alt"></i> </span>MY REPORTS</a>
  <a href="Notification.php"><span> <i class="glyphicon glyphicon-bell"></i> </span>NOTIFICATIONS</a>
  <a href="includes/logout.php"><span> <i class="glyphicon glyphicon-log-out"></i> </span>LOGOUT</a>
</div>
