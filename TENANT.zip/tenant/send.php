
<?php
session_start();
include_once 'includes/header.php';
include_once 'includes/usernav.php'; 
include ("includes/database_connect.php");
$house_code = null;$message = null;

if (isset($_POST['send'])) {

$message =addslashes ($_POST['message']);
$house_code = addslashes ($_POST['house_code']);
$from = $_SESSION['u_id'];
if(isset($house_code) && isset($message)){
if(!empty($house_code) && !empty($message)){
           
          // Get Recipient Id
          $check ="SELECT id FROM assigned_houses WHERE house_code='$house_code'";
          $isExist = mysqli_query($conn,$check);
          $isFound =mysqli_num_rows($isExist);
          if ($isFound > 0) {
            $getUSerID = mysqli_fetch_array($isExist,MYSQLI_ASSOC);
            $to = $getUSerID['id'];
            $sent_time = date("D M Y H:i A");
           //INSERT MESSAGE
            $query = "INSERT INTO messages(sent_from,sent_to,message,senttime,seen) VALUES('$from','$to','$message','$sent_time','no')";  
            if(mysqli_query($conn, $query)){
              
                 $msg ="<p class='alert alert-success' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message sent !</p>";
                echo $msg;   
                //sleep(2) ; 
              header('Location: Notification.php?message=sent');
                
               
            }else{

                $error ="<p class='alert alert-warning' style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>Message not sent !!</p>";
                echo $error;
              }
                
            }else{
               $error ="<p class='alert alert-danger'style='width:48%; margin-left:1%;font-size:14px;text-align:center;'>We Encountered a problem while sending the message !</p>";
                echo $error;
            }
          }
        }
      }
        //MAKE USER DONT SEND MESSAGE TO HIMSELF

          $loggedUser = $_SESSION['u_name'];
          $sqlGet = "SELECT house_code FROM `assigned_houses` WHERE tenant_name = '$loggedUser'";
          $runQuery = mysqli_query($conn,$sqlGet);
          $is_exist = mysqli_fetch_array($runQuery,MYSQLI_ASSOC);
          $currentCode = $is_exist['house_code'];
          //GRAB OTHER USERS
          $rooms=mysqli_query($conn, "SELECT house_no FROM houses WHERE flag ='Occupied' AND house_no !='$currentCode'");

?>

<!--/span-->
        <div class="box col-md-6">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                  <p align="center"><?php echo ucfirst($_SESSION['u_cat']. " ".$_SESSION['u_name'].$_SESSION['u_lname'] );?></p>
                  <h4 align="center">Chatroom</h4>
                    <form action="" method="post">
                          <label for="house_code"><b>Message To:</b></label>
                          </br>
                          <?php
                          echo '<select name="house_code" class="form-control">'; 
                          while($row = mysqli_fetch_array($rooms))
                          {

                           echo '<option value="'.$row['house_no'].'">'.$row['house_no'].'</option>';
                          }
                          echo '</select>';
                          ?>
                          <br>
                          <textarea class="form-control" name="message" placeholder="Hi,Admin send message to your tenants..." value="<?php echo $message; ?>" ></textarea>
                          <br>
                          <button type="submit" class="btn btn-primary" name="send">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
        <!--/span-->
