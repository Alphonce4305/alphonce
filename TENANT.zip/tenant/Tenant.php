<?php
session_start();
include ("includes/nav.php");
include ("includes/database_connect.php");

if (!isset($_POST['register'])) {
  $fname = null;
$sname = null;
$email = null;
$id_no = null;
$psw = null;

}else{
$fname = addslashes ($_POST['fname']);
$sname = addslashes ($_POST['sname']);
$email = addslashes ($_POST['email']);
$id_no = addslashes ($_POST['id_no']);
$psw = $_POST['psw'];


//HASH PASSWORD
$newpws = hash('sha256', $psw);

if(isset($fname) && isset($sname) && isset($email) && isset($id_no) && isset($psw)){
        if(!empty($fname) && !empty($sname) && !empty($email) && !empty($id_no)  && !empty($psw)){

            // check if user exists
          $checkUser ="SELECT email , id_no FROM tenant_Details WHERE email='$email' OR id_no='$id_no'";
          $isUserExist = mysqli_query($conn,$checkUser);
          $foundUsers =mysqli_num_rows($isUserExist);
          if ($foundUsers > 0) {
            $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>User Already Exists !</p>";
                  echo $error;
                  
          }else{
        $query = "INSERT INTO tenant_Details(fname,sname,email,id_no,password) VALUES('$fname','$sname','$email','$id_no','$newpws')";

        if(mysqli_query($conn, $query)){
                $msg ="<p class='alert alert-success' style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>Registration Successful</p>";
                  echo $msg;
                  //Call back rgistered user
                  $registered_user ="SELECT fname FROM tenant_Details WHERE email='$email' LIMIT 1";
                  $getuser = mysqli_query($conn,$registered_user);
                  foreach ($getuser as $user) {
                    $lastuser = $user['fname'];
                    echo "<p style='color:green;text-align:center;font-size:24px;font-weight:bold;'>Hi, $lastuser <a href='login.php'>Login  Here</a></p>";
                    unset($_POST['register']);
                  }
        }else{
               $error ="<p class='alert alert-danger'style='width:30%; margin-left:36%;font-size:20px;text-align:center;'>Invalid Login Credentials !</p>";
                  echo $error;
        }

}
}
}
}

?>

<?php 
include_once 'includes/header.php';
 ?>
<div class="container">
<div class="panel panel-primary">
  <div class="panel-heading"><h4 align="center"> Add New Tenant</h4></div>
  <div class="panel-body" style="width: 50%;margin-left: 25%;text-align: center;">
    <form action="" method="post">
    <p align="center">Please fill in this form to create a Tenant Account.</p>
    <hr>

    <label for="fname" style="visibility: hidden;"><b>First Name</b></label>
    <input type="text" placeholder="First Name" name="fname" required class="form-control">

    <label for="sname" style="visibility: hidden;"><b>Second Name</b></label>
    <input type="text" placeholder="Second Name" name="sname" required class="form-control">

    <label for="email" style="visibility: hidden;"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required class="form-control">

    <label for="id_no" style="visibility: hidden;"><b>ID Number</b></label>
    <input type="text" placeholder="ID Number" name="id_no" required class="form-control">
  
    <label for="id_no" style="visibility: hidden;"><b>Password</b></label>
    <input type="password" placeholder="Password" name="psw" required class="form-control">
<br>
    <button type="submit" class="btn btn-danger pull-right" name="register" >Register</button>
  
</form>
  </div> 
</div>
</div>
</div>
<?php include_once 'includes/footer.php'; ?>
